# Task-1: Data Loading and Exploration
from turtle import pd
import turtle

import pandas as pd # pyright: ignore[reportMissingModuleSource]
import numpy as np
# Load Dataset
df = turtle.pd.read_csv("Housing.csv")

# First 10 Rows
print("First 10 Rows")
print(df.head(10))

# Shape
print("\nRows and Columns:")
print(df.shape)

# Columns
print("\nColumns:")
print(df.columns)

# Missing Values
print("\nMissing Values:")
print(df.isnull().sum())

# Data Types
print("\nData Types:")
print(df.dtypes)

# Target and Features
target = 'price'
features = df.drop('price', axis=1)

print("\nTarget Column:", target)
print("Feature Columns:")
print(features.columns)
#Task-2: Data Cleaning
# Check duplicates
print("Duplicate Rows:", df.duplicated().sum())

# Remove duplicates
df = df.drop_duplicates()

# Missing Values
df = df.dropna()

# Convert yes/no columns

binary_cols = [
    'mainroad',
    'guestroom',
    'basement',
    'hotwaterheating',
    'airconditioning',
    'prefarea'
]

for col in binary_cols:
    df[col] = df[col].map({'yes':1,'no':0})

# One-Hot Encoding
df = turtle.pd.get_dummies(df,
                    columns=['furnishingstatus'],
                    drop_first=True)

print(df.head())
# Task-3: Model Building
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor

from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score

# Features and Target

X = df.drop('price', axis=1)
y = df['price']

# Split Dataset

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42
)

# -------------------
# Linear Regression
# -------------------

lr = LinearRegression()

lr.fit(X_train, y_train)

lr_pred = lr.predict(X_test)

lr_mae = mean_absolute_error(y_test, lr_pred)
lr_rmse = np.sqrt(mean_squared_error(y_test, lr_pred))
lr_r2 = r2_score(y_test, lr_pred)

print("Linear Regression Results")
print("MAE:", lr_mae)
print("RMSE:", lr_rmse)
print("R2 Score:", lr_r2)

# -------------------
# Random Forest
# -------------------

rf = RandomForestRegressor(
    n_estimators=100,
    random_state=42
)

rf.fit(X_train, y_train)

rf_pred = rf.predict(X_test)

rf_mae = mean_absolute_error(y_test, rf_pred)
rf_rmse = np.sqrt(mean_squared_error(y_test, rf_pred))
rf_r2 = r2_score(y_test, rf_pred)

print("\nRandom Forest Results")
print("MAE:", rf_mae)
print("RMSE:", rf_rmse)
print("R2 Score:", rf_r2)

# Comparison

comparison = turtle.pd.DataFrame({
    'Model':['Linear Regression','Random Forest'],
    'MAE':[lr_mae,rf_mae],
    'RMSE':[lr_rmse,rf_rmse],
    'R2':[lr_r2,rf_r2]
})

print("\nModel Comparison")
print(comparison)
# Task-4: Visualization
# Chart-1: House Price Distribution
import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(8,5))

sns.histplot(df['price'],
             bins=30,
             kde=True)

plt.title("Distribution of House Prices")
plt.xlabel("Price")
plt.ylabel("Count")

plt.savefig("house_price_distribution.png")
plt.show()
#chart-2 correlation heatmap
plt.figure(figsize=(12,8))

sns.heatmap(df.corr(),
            annot=False,
            cmap='coolwarm')

plt.title("Correlation Heatmap")

plt.savefig("correlation_heatmap.png")

plt.show()
#Actual vs predicted prices
plt.figure(figsize=(8,5))

plt.scatter(y_test,
            rf_pred)

plt.xlabel("Actual Price")
plt.ylabel("Predicted Price")

plt.title("Actual vs Predicted House Prices")

plt.savefig("actual_vs_predicted.png")

plt.show()
#Feauture importance
feature_importance = turtle.pd.DataFrame({
    'Feature':X.columns,
    'Importance':rf.feature_importances_
})

feature_importance = feature_importance.sort_values(
    by='Importance',
    ascending=False
)

print(feature_importance)

plt.figure(figsize=(10,6))

sns.barplot(
    x='Importance',
    y='Feature',
    data=feature_importance.head(10)
)

plt.title("Top 10 Important Features")

plt.show()